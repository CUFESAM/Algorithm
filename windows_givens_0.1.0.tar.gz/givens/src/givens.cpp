#include <Rcpp.h>
using namespace Rcpp;

//' @name givens
//' @title Solve equation set via givens transformation
//' @description Using givens transformation to save unnecessary computation
//' @param L an n*n lower triangular matrix
//' @param k the k-th row to be removed
//' @details When solve object function of linear regression,
//' it’s necessary to calculate t(X)\%*\%X, which is a lot of computation expensive with regards
//' to variable coming in and out in lasso. Using givens transformation to spare repeating
//' computation and get coefficient from the original lower triangular matrix.
//' @return givens gives the (n-1)*(n-1) dimensional lower triangular
//' coefficient matrix from a n*n lower triangular coefficient matrix removing some variable.
//' @references https://www.researchgate.net/publication/228964850_Generalized_Givens_Transformation_and_its_Application
//' @useDynLib givens
//' @importFrom Rcpp sourceCpp
//' @export

// [[Rcpp::plugins("cpp11")]]
// [[Rcpp::export]]

NumericMatrix givens(NumericMatrix L, int k){
  int p = L.cols();
  int n = L.rows();
  //Rcout << n;
  if (p != n)
    Rcerr << 'Wrong Matrix!';
  if ((k-1) > p)
    Rcerr << 'Wrong input of k!';
  NumericMatrix Lk(p-1,n);
  for(int i=0;i < k-1;i++)
    Lk(i,_) = L(i,_);
  for(int j = k;j < p;j++)
    Lk(j-1,_) = L(j,_);

  int mk = k-1;
  while (mk < p-1){
    NumericVector mx(2);
    mx[0] = Lk(mk,mk);
    mx[1] = Lk(mk,mk+1);
    double lmx = sqrt(mx[0]*mx[0]+mx[1]*mx[1]);
    Lk(mk,mk) = lmx;
    Lk(mk,mk+1) = 0;

    double mc = mx[0]/lmx;
    double ms = mx[1]/lmx;

    if(mk < p-2){
      for(int i = mk+1;i < p-1;i++){
        double m = Lk(i,mk)*mc+Lk(i,mk+1)*ms;
        double n = Lk(i,mk)*(-ms) + Lk(i,mk+1)*mc;
        Lk(i,mk) = m;
        Lk(i,mk+1) = n;
      }
    }
    mk += 1;
  }
  NumericMatrix LK(p-1,p-1);
  for(int i =0;i < p-1;i++)
    LK(_,i) = Lk(_,i);
  return(LK);
}
