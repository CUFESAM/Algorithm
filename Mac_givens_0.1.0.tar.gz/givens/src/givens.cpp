//
//  main.cpp
//  testcpp
//
//  Created by LEWIN CHO on 02/05/2018.
//  Copyright © 2018 LEWIN CHO. All rights reserved.
//

#include <Rcpp.h>

using namespace Rcpp;

// [[Rcpp::plugins("cpp11")]]
// [[Rcpp::export]]


NumericMatrix givens(NumericMatrix L, int k){
	int p = L.cols();
    int n = L.rows();
    //Rcout << n;
    if (p != n)
        Rcerr << "Wrong Matrix!";
    if ((k-1) > p)
        Rcerr << "Wrong input of k!";
    NumericMatrix Lk(p-1,n);
    for(int i=0;i < k-1;i++)
      Lk(i,_) = L(i,_);
    for(int j = k;j < p;j++)
      Lk(j-1,_) = L(j,_);

	int mk = k-1;
	while (mk < p-1){
		NumericVector mx(2);
	  mx[0] = Lk(mk,mk);
	  mx[1] = Lk(mk,mk+1);
		double lmx = sqrt(mx[0]*mx[0]+mx[1]*mx[1]);
		Lk(mk,mk) = lmx;
		Lk(mk,mk+1) = 0;

		double mc = mx[0]/lmx;
		double ms = mx[1]/lmx;

		if(mk < p-2){
			for(int i = mk+1;i < p-1;i++){
				double m = Lk(i,mk)*mc+Lk(i,mk+1)*ms;
				double n = Lk(i,mk)*(-ms) + Lk(i,mk+1)*mc;
				Lk(i,mk) = m;
				Lk(i,mk+1) = n;
			}
		}
		mk += 1;
	}
	NumericMatrix LK(p-1,p-1);
	for(int i =0;i < p-1;i++)
		LK(_,i) = Lk(_,i);
	return(LK);
}
